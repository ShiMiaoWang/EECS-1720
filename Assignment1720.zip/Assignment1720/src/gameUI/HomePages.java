package gameUI;

import javax.swing.*;

import main.Game;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomePages extends JFrame {

	public HomePages() {
		// Set basic properties
		setTitle("Super Madiao");
		setSize(1152, 864);

		// Create the main panel
		JPanel mainPanel = new JPanel(new BorderLayout()) {
			Image backgroundImage = new ImageIcon(getClass().getResource("/icons/title.png")).getImage();

			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				if (backgroundImage != null) {
					g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
				}
			}
		};

		setContentPane(mainPanel);

		// Use GridBagLayout to precisely control button positions
		JPanel buttonPanel = new JPanel(new GridBagLayout());
		buttonPanel.setOpaque(false); // Transparent background to show the background image

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(10, 0, 10, 0); // Button spacing

		// START button
		JButton startButton = new JButton();

		ImageIcon startIcon = new ImageIcon(getClass().getResource("/icons/start.png"));
		Image scaledStart = startIcon.getImage().getScaledInstance(200, 60, Image.SCALE_SMOOTH);

		startButton.setIcon(new ImageIcon(scaledStart));
		startButton.setBorderPainted(false); // Set true for debugging icons
		startButton.setContentAreaFilled(false);
		startButton.setFocusPainted(false);
		startButton.setPreferredSize(new Dimension(200, 60)); // Set button size

		// START button click event
		startButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
		        JOptionPane.showMessageDialog(HomePages.this, "Game started! ");
		        HomePages.this.dispose();  
		        new Game(null);           
		    }
		});

		// Set the position of the START button
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.CENTER;
		buttonPanel.add(startButton, gbc);

		// HELP button
		JButton helpButton = new JButton();

		ImageIcon helpIcon = new ImageIcon(getClass().getResource("/icons/help.png"));

		// Adjust the button image size to match the HELP rectangle in the background
		Image scaledHelp = helpIcon.getImage().getScaledInstance(200, 60, Image.SCALE_SMOOTH);
		helpButton.setIcon(new ImageIcon(scaledHelp));
		// Remove the default border and background of the button
		helpButton.setBorderPainted(false); // Set true for debugging icons
		helpButton.setContentAreaFilled(false);
		helpButton.setFocusPainted(false);
		helpButton.setPreferredSize(new Dimension(200, 60)); // Set button size

		// HELP button
		helpButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String helpMessage = "Super Madiao Game Rules:\n"
						+ "1. Each player takes turns playing cards, declaring the rank of the card (e.g., KING).\n"
						+ "2. Other players can challenge; if the declaration is incorrect, the liar takes all cards in the pile.\n"
						+ "3. If the challenge fails, the challenger takes the cards in the pile.\n"
						+ "4. The first player to empty their hand wins!";
				JOptionPane.showMessageDialog(HomePages.this, helpMessage, "Game Help",
						JOptionPane.INFORMATION_MESSAGE);
			}
		});

		// Set the position of the HELP button
		gbc.gridx = 0;
		gbc.gridy = 1;
		buttonPanel.add(helpButton, gbc);

		// to the center
		mainPanel.add(buttonPanel, BorderLayout.CENTER);

		// Add top spacing to move the buttons down to align with the START and HELP
		// areas in the background image
		mainPanel.add(Box.createVerticalStrut(350), BorderLayout.NORTH);

		// Make the window visible
		setVisible(true);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new HomePages();
			}
		});
	}
}