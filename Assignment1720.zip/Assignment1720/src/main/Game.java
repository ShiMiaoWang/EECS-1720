package main;

import model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Game extends JFrame {

    private Manager manager;
    private JPanel playerHandPanel;
    private JComboBox<Card.Rank> rankComboBox;
    private JButton playButton, challengeButton;
    private JLabel statusLabel;
    private JPanel pilePanel;

    private Player currentPlayer;
    private List<Card> selectedCards;

    public Game(List<Player> players) {
        if (players == null || players.isEmpty()) {
            players = new ArrayList<>();
            players.add(new Player("Alice"));
            players.add(new Player("Bob"));
        }

        this.manager = new Manager(players);
        this.currentPlayer = manager.getCurrentPlayer();
        this.selectedCards = new ArrayList<>();

        setTitle("Super Madiao Game");
        setSize(1152, 864);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        setupStatusBar();
        setupPlayerHand();
        setupControlPanel();
        setupPileDisplay();

        refreshUI();
        setVisible(true);
    }

    private void setupStatusBar() {
        statusLabel = new JLabel("Game Started. Current Player: " + currentPlayer.getName());
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(statusLabel, BorderLayout.NORTH);
    }

    private void setupPlayerHand() {
        playerHandPanel = new JPanel();
        playerHandPanel.setLayout(new FlowLayout());
        add(new JScrollPane(playerHandPanel), BorderLayout.SOUTH);
    }

    private void setupControlPanel() {
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());

        rankComboBox = new JComboBox<>(Card.Rank.values());
        playButton = new JButton("Play Selected Cards");
        challengeButton = new JButton("Challenge");

        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Card.Rank declaredRank = (Card.Rank) rankComboBox.getSelectedItem();
                    manager.playCards(currentPlayer, selectedCards, declaredRank);
                    selectedCards.clear();
                    refreshUI();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(Game.this, ex.getMessage());
                }
            }
        });

        challengeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Player challenger = manager.getCurrentPlayer();
                boolean result = manager.challengePlayer(challenger);
                JOptionPane.showMessageDialog(Game.this, result ? "Challenge successful!" : "Challenge failed!");
                refreshUI();
            }
        });

        controlPanel.add(new JLabel("Declare Rank: "));
        controlPanel.add(rankComboBox);
        controlPanel.add(playButton);
        controlPanel.add(challengeButton);

        add(controlPanel, BorderLayout.CENTER);
    }

    private void setupPileDisplay() {
        pilePanel = new JPanel();
        pilePanel.setPreferredSize(new Dimension(600, 200));
        add(pilePanel, BorderLayout.EAST);
    }

    private void refreshUI() {
        currentPlayer = manager.getCurrentPlayer();
        statusLabel.setText("Current Player: " + currentPlayer.getName());

        playerHandPanel.removeAll();
        for (Card card : currentPlayer.getHand()) {
            JButton cardButton = new JButton(card.toString());
            cardButton.addActionListener(e -> {
                if (selectedCards.contains(card)) {
                    selectedCards.remove(card);
                    cardButton.setBackground(null);
                } else {
                    selectedCards.add(card);
                    cardButton.setBackground(Color.YELLOW);
                }
            });
            playerHandPanel.add(cardButton);
        }

        pilePanel.removeAll();
        Play lastPlay = manager.getPile().getLastPlay();
        if (lastPlay != null) {
            pilePanel.add(new JLabel("Last Played: " + lastPlay.getCards() + " by " + lastPlay.getPlayer().getName()));
        } else {
            pilePanel.add(new JLabel("No cards in pile yet."));
        }

        revalidate();
        repaint();
    }
}
